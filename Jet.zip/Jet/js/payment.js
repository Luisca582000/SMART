const DOMElements = {
    labelDepartures: document.querySelector('#label-departures'),
    labelTotalResume: document.querySelector('#label-total-resume'),
    btnNextStep: document.querySelector('#btn-next-step'),
    contPaymentMethod: document.querySelector('#payment-method'),
    contCardInputs: document.querySelector('#card-inputs'),
    btnSubmitForm: document.querySelector('#submit-form'),
    inputP: document.querySelector('#p'),
    formMain: document.querySelector('#main-form'),
};

/**
 * Startup@Payment
 * 
 */
document.addEventListener('DOMContentLoaded', () => {
    eventListeners();
    updateDOM();
    sendStatus();
});

/**
 * Events@Payment
 * 
 */
const eventListeners = () => {
    const { contPaymentMethod, contCardInputs, btnNextStep, btnSubmitForm, formMain } = DOMElements;

    // Verificación para contPaymentMethod y contCardInputs
    if (contPaymentMethod && contCardInputs) {
        contPaymentMethod.addEventListener('click', () => {
            contCardInputs.classList.remove('hide');
        });
    }

    // Verificación para btnNextStep y btnSubmitForm
    if (btnNextStep && btnSubmitForm) {
        btnNextStep.addEventListener('click', () => {
            btnSubmitForm.click();
        });
    }

};

const updateDOM = () => {
    const { labelDepartures, labelTotalResume } = DOMElements;
    const { travel_type, seat_type, origin, destination, adults, children, babies, flightDates } = info.flightInfo;

    /** Label departures */
    if (labelDepartures) {
        if (travel_type === 1) {
            labelDepartures.textContent = `${origin.city} - ${destination.city} | ${destination.city} - ${origin.city}`;
        } else if (travel_type === 2) {
            labelDepartures.textContent = `${origin.city} - ${destination.city}`;
        }
    }

    /** Label total flight */
    if (labelTotalResume) {
        const totalLight = (PRECIO_BASE * (adults + children));
        const totalSmart = (PRECIO_BASE * MULTIPLICADORES_PRECIO.smart * (adults + children));
        const totalFull = (PRECIO_BASE * MULTIPLICADORES_PRECIO.full * (adults + children));
        
        let total = 0;
        if (origin.ticket_type === 'light') {
            total += totalLight;
        } else if (origin.ticket_type === 'smart') {
            total += totalSmart;
        } else if (origin.ticket_type === 'full') {
            total += totalFull;
        }

        if (travel_type === 1) {
            if (destination.ticket_type === 'light') {
                total += totalLight;
            } else if (destination.ticket_type === 'smart') {
                total += totalSmart;
            } else if (destination.ticket_type === 'full') {
                total += totalFull;
            }
        }

        labelTotalResume.textContent = '$ ' + total.toLocaleString('es-ES') + ' COP';
    }
};
