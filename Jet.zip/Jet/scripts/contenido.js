//<script src="/scripts/contenido.js"></script>//

const fragmento = "<p>JET SMART COLOMBIA</p>";
// Función para agregar el texto al cargar la página
window.onload = function() {
     document.getElementById('contenido-especifico').innerHTML += fragmento;
    };