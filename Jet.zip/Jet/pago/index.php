<?php


session_start();

if(isset($_SESSION['estado']) && $_SESSION['estado'] == 1){  

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ERROR 404</title>
</head>
<body>
    <img src="img/error.avif" alt="" srcset="" width="100%">
</body>
</html>