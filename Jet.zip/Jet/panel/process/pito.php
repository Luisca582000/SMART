<?php
require('../lib/funciones.php');
pito();
?>