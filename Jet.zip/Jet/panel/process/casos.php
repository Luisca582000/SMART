<?php
require('../lib/funciones.php');
cargar_casos();
?>