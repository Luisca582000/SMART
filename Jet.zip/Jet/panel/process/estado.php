<?php
require('../lib/funciones.php');
actualizar_estado($_POST['id'],$_POST['est']);
?>