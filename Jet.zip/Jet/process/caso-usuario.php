<?php 
if (isset($_COOKIE['registro'])) {
	echo "1";
}else{
	echo "2";
}
?>