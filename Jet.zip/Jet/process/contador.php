<?php 
require('../panel/lib/funciones.php');
contador();
?>